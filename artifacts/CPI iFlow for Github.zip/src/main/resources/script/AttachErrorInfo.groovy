import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    def properties = message.getProperties()
    def headers = message.getHeaders()

    // def addToLogFlag = properties.getOrDefault("errorLogAttachments", "No") == "Yes"
    def exception = properties.get('CamelExceptionCaught')

    def messageLog = messageLogFactory.getMessageLog(message)

    if (exception?.getClass()?.getCanonicalName()?.equals('org.apache.camel.component.ahc.AhcOperationFailedException')) {
        message.setProperty('http.StatusCode', exception.getStatusCode())
        message.setProperty('http.StatusText', exception.getStatusText())
        message.setProperty('http.ResponseBody', exception.getResponseBody())
        if (messageLog) {
            messageLog.addAttachmentAsString('Response Body', exception.getResponseBody(), 'text/plain')
        }
    }

    if (messageLog) {
        def headersText = ''
        headers.each { k, v -> headersText += "${k}: ${v}" + "\n" }
        messageLog.addAttachmentAsString('Headers', headersText, 'text/plain')
        
        def detailErrorInfo = ''
        // detailErrorInfo += "Integration Flow Name: " + properties.get("iFlowName") + "\n"
        detailErrorInfo += "Message Processing Log ID: " + properties.get("SAP_MessageProcessingLogID") + "\n"
        detailErrorInfo += "Message Processing Log Correlation ID: " + headers.get("SAP_MplCorrelationId") + "\n"
        detailErrorInfo += "Timestamp: " + properties.get("CamelCreatedTimestamp") + "\n"
        detailErrorInfo += "Exception Message: " + properties.get("exceptionMessage") + "\n"
        detailErrorInfo += "Exception Stacktrace: " + properties.get("exceptionStacktrace") + "\n"
        messageLog.addAttachmentAsString('Detialed Error Infomation', detailErrorInfo, 'text/plain')

        if (properties.get("OriginalPayload")) {
            messageLog.addAttachmentAsString('Original Payload', properties.get("OriginalPayload"), 'text/plain')
        }

        if (properties.get("RequestPayload")) {
            messageLog.addAttachmentAsString('Request Payload', properties.get("RequestPayload"), 'text/plain')
        }
    }

    return message
}