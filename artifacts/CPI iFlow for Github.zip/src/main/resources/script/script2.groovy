import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {

     def messageLog = messageLogFactory.getMessageLog(message);
     if(messageLog != null){

          def UserName = message.getProperty("person_id_external");
          if(UserName!=null){
               messageLog.addCustomHeaderProperty("UserName", UserName);        
     }
     }
     return message;
}